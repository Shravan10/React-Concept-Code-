
export const STORE_COMPOSE_MAIL= "STORE_COMPOSE_MAIL";

export const storeComposeMail = (composeData) => ({ type: STORE_COMPOSE_MAIL, payload: composeData});