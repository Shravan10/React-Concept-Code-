import {RECEIVE_API_DATA, DELETE_INBOX_MAIL} from "../actions/inbox.js"


let initialState = {};


export default (state={},action) => {
  switch(action.type){
    case RECEIVE_API_DATA:
      initialState ={data : action.payload};
    	return initialState;

    case DELETE_INBOX_MAIL:
      var data = initialState.data.filter((st) => {
        return st.id != action.payload
      })
      initialState ={data :data};
      return initialState;
    default:
            return state;
  }
};